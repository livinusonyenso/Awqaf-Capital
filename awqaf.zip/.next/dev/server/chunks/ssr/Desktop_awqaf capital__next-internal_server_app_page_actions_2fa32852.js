module.exports = [
"[project]/Desktop/awqaf capital/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_awqaf%20capital__next-internal_server_app_page_actions_2fa32852.js.map