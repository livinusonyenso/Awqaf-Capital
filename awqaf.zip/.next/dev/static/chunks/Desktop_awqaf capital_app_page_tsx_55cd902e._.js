(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_awqaf capital_components_06e33a4c._.js",
  "static/chunks/node_modules_5f0a72b8._.js"
],
    source: "dynamic"
});
