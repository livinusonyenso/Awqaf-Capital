(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_awqaf-capital_components_fcb99de3._.js",
  "static/chunks/6edcf_bc660190._.js"
],
    source: "dynamic"
});
