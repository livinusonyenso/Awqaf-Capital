(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_3c6cae06._.js",
  "static/chunks/6edcf_next_dist_compiled_react-dom_3e4785eb._.js",
  "static/chunks/6edcf_next_dist_compiled_react-server-dom-turbopack_3020ed2a._.js",
  "static/chunks/6edcf_next_dist_compiled_next-devtools_index_dc2590b5.js",
  "static/chunks/6edcf_next_dist_compiled_7c5ba666._.js",
  "static/chunks/6edcf_next_dist_client_8897c095._.js",
  "static/chunks/6edcf_next_dist_c44bada9._.js",
  "static/chunks/6edcf_@swc_helpers_cjs_ccc82755._.js"
],
    source: "entry"
});
