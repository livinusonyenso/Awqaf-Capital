(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/components_129b7173._.js",
  "static/chunks/node_modules_0e5d4c5c._.js"
],
    source: "dynamic"
});
