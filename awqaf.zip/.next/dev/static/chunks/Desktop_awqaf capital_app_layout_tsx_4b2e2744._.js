(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__73077170._.css",
  "static/chunks/94ae0_c778dead._.js",
  "static/chunks/Desktop_awqaf capital_components_865fe738._.js"
],
    source: "dynamic"
});
