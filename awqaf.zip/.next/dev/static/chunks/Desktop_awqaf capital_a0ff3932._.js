(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_6a944ee0._.js",
  "static/chunks/94ae0_next_dist_compiled_react-dom_5f5b6ddf._.js",
  "static/chunks/94ae0_next_dist_compiled_react-server-dom-turbopack_4f77af46._.js",
  "static/chunks/94ae0_next_dist_compiled_next-devtools_index_5e349526.js",
  "static/chunks/94ae0_next_dist_compiled_b8b654f2._.js",
  "static/chunks/94ae0_next_dist_client_c540ddc9._.js",
  "static/chunks/94ae0_next_dist_19b02b44._.js",
  "static/chunks/94ae0_@swc_helpers_cjs_a8245bf8._.js"
],
    source: "entry"
});
