(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__f8896ce9._.css",
  "static/chunks/6edcf_1272fb5b._.js"
],
    source: "dynamic"
});
